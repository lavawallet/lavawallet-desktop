# LavaWallet (Desktop)


![image](https://user-images.githubusercontent.com/38132633/42248915-2f98be9c-7ef6-11e8-9a46-68c2c0f4ea35.png)
![image](https://user-images.githubusercontent.com/38132633/42248914-2d7dc512-7ef6-11e8-87dc-ab63b626f468.png)



### Release 0.20 Beta 

https://github.com/lavawallet/lavawallet-desktop/raw/master/dist/LavaWallet-Win.zip



## TODO
1. Finish sidebar for monitoring TX
2. Replace Keythereum with Ethers





## To Use

```bash

install NodeJS 10

# Install dependencies
npm install
# Compile
npm run webpack
# Run the app
npm run app
```  

# Developer TODO
1. Finish the transfer tab

2. Integrate lava balance and lava transfers


Rebuild Eletron with
electron-rebuild -v 4.1.0



### Menus

-Home
* Create New Account
* Import Existing Eth Account From PKey

* Watch an Account (addressbook) -- Addressbook is a part of 'home' ?
* Show contract address for active token

-Accounts
* There is a sidebar along the left with nice icons , like photon demo
* Right side shows the deposit address and helps you fill the acct, button for deposit to lava
* shows vanilla balance and lava balance

-Transfer
*

-Settings  (also accessible from home)
* Lets you edit the 'active token' address - the primary token the wallet uses



## package to exe



## License

[CC0 1.0 (Public Domain)](LICENSE.md)
